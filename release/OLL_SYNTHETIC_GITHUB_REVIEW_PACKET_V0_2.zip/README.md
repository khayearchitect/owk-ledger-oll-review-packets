# Synthetic GitHub Test Packet

Status: Draft packet created
Date: 2026-07-23
Packet ID: OLL-SYN-001

## Purpose

Create a synthetic public packet to invite critique from reviewers without exposing private data.

## Required Framing

```text
This packet uses synthetic data. We are testing whether this reviewer-ready packet would help a reviewer understand a small business record set faster. We are not asking for tax, legal, or accounting advice. Please point out what is missing, unclear, unnecessary, or useful.
```

## Synthetic Data Only

No real business, client, employee, bank, invoice, payment, tax, ID, or registration data is used.

## Main Packet

- `packet/OLL_REVIEWER_READY_PACKET_BLUE_BASIN_SYNTHETIC.md`

## CSV Exports

- `csv/clients.csv`
- `csv/documents.csv`
- `csv/quotes.csv`
- `csv/invoices.csv`
- `csv/payment_evidence.csv`
- `csv/invoice_lifecycle.csv`
- `csv/hr_summary.csv`
- `csv/missing_information.csv`
- `csv/gap_status.csv`
- `csv/expenses.csv`
- `csv/bank_statement_stub.csv`

## Source Documents

- `source_docs/QUOOLL001.md`
- `source_docs/INVOLL001.md`
- `source_docs/INVOLL002.md`
- `source_docs/INVOLL003.md`
- `source_docs/PAYOLL001.md`
- `source_docs/LETOLL001.md`
- `source_docs/SOURCE_INDEX.md`

## GitHub Draft

- `github/GITHUB_REVIEW_ISSUE_COPY.md`

## EGPM v0.2 Correction Notes

After EGPM review, v0.2 adds:

- simple expense summary
- bank statement stub
- gap status export
- visible client VAT/tax identifier field
- stronger payroll deduction boundary wording
- additional gaps for bank statement and input VAT / expense support

The GitHub review issue draft was copied to `06_output_drafts/GITHUB_REVIEW_ISSUE_COPY_OLL_SYN_001.md` and is no longer included in the reviewer packet ZIP.

## Current ZIP

- `dist/OLL_SYNTHETIC_GITHUB_REVIEW_PACKET_V0_2.zip`
